
(function ($) {
    "use strict";
    $(document).ready(function () {
        $('.slider').slider({})
    });

})(jQuery);
