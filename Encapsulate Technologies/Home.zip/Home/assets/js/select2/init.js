
(function ($) {
    "use strict";
    $(document).ready(function () {
        $(".ct-js-select").select2();
    });

})(jQuery);
