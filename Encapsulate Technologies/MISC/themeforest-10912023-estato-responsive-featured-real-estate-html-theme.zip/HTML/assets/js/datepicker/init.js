(function ($) {
    "use strict";
    $(document).ready(function(){
        $('.ct-js-datetimePicker div').datepicker({
            todayHighlight: true
        });
    })
}(jQuery));